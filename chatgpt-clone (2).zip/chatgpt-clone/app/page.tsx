import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Bot, ArrowRight, LogIn } from "lucide-react"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      {/* Header with login button */}
      <header className="container mx-auto py-6 px-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Bot className="h-8 w-8 text-blue-500" />
          <h1 className="text-2xl font-bold">AI Chat Assistant</h1>
        </div>
        <Link href="/login">
          <Button variant="ghost" className="flex items-center gap-2">
            <LogIn className="h-5 w-5" />
            <span>Login</span>
          </Button>
        </Link>
      </header>

      {/* Hero section */}
      <main className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-purple-600 text-transparent bg-clip-text">
            Your Intelligent AI Assistant
          </h2>
          <p className="text-xl text-gray-400 mb-12">
            Experience the power of AI with our advanced chat assistant. Get instant answers, creative content, and
            helpful insights - all in one place.
          </p>

          <div className="flex justify-center">
            <Link href="/chat">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 rounded-full text-lg font-medium flex items-center gap-2 transition-all hover:scale-105">
                Start Chatting
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>

        {/* Features section */}
        <div className="grid md:grid-cols-3 gap-8 mt-24">
          <div className="bg-gray-800 p-6 rounded-xl">
            <div className="bg-blue-600/20 w-12 h-12 flex items-center justify-center rounded-lg mb-4">
              <Bot className="h-6 w-6 text-blue-500" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Intelligent Responses</h3>
            <p className="text-gray-400">Get smart, contextual answers to all your questions in seconds.</p>
          </div>

          <div className="bg-gray-800 p-6 rounded-xl">
            <div className="bg-purple-600/20 w-12 h-12 flex items-center justify-center rounded-lg mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-purple-500"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Lightning Fast</h3>
            <p className="text-gray-400">Experience real-time streaming responses with minimal latency.</p>
          </div>

          <div className="bg-gray-800 p-6 rounded-xl">
            <div className="bg-green-600/20 w-12 h-12 flex items-center justify-center rounded-lg mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-green-500"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Secure & Private</h3>
            <p className="text-gray-400">Your conversations are private and your data is never shared.</p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="container mx-auto py-8 px-4 border-t border-gray-800 mt-20">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500">© 2025 AI Chat Assistant. All rights reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="text-gray-500 hover:text-gray-300">
              Terms
            </a>
            <a href="#" className="text-gray-500 hover:text-gray-300">
              Privacy
            </a>
            <a href="#" className="text-gray-500 hover:text-gray-300">
              Contact
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}

