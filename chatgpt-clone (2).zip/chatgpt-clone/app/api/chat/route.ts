import { openai } from "@ai-sdk/openai"
import { streamText } from "ai"

// Allow streaming responses up to 30 seconds
export const maxDuration = 30

export async function POST(req: Request) {
  const { messages } = await req.json()

  // Log incoming messages for debugging
  console.log("Received chat request:", messages)

  try {
    // Use OpenAI's GPT model to generate a response
    const result = streamText({
      model: openai("gpt-4o"),
      messages,
      temperature: 0.7, // Add some creativity but keep responses focused
      maxTokens: 1000, // Limit response length
      system:
        "You are a helpful AI assistant that provides informative, accurate, and friendly responses. You can help with a wide range of topics including answering questions, providing explanations, giving recommendations, and engaging in casual conversation.", // System prompt to guide the AI's behavior
    })

    // Return the streaming response
    return result.toDataStreamResponse()
  } catch (error) {
    console.error("Error generating AI response:", error)
    return new Response(JSON.stringify({ error: "Failed to generate response" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

