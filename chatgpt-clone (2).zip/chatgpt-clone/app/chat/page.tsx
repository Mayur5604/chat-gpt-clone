"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useChat } from "ai/react"
import { Send, Bot, User, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"
import Link from "next/link"

export default function ChatPage() {
  // Use the useChat hook from the AI SDK to handle chat state and API communication
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: "/api/chat", // Point to our API route
    onResponse: (response) => {
      // This is called when we get a response from the API
      if (response.status === 200) {
        console.log("Received successful response from AI")
      } else {
        console.error("Error from AI response:", response.statusText)
      }
    },
  })

  const [inputHeight, setInputHeight] = useState("h-12")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to the bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    handleInputChange(e)
    // Adjust height based on content
    const height = e.target.scrollHeight
    if (height < 200) {
      setInputHeight(`h-${Math.max(12, Math.ceil(height / 16) * 4)}`)
    } else {
      setInputHeight("h-48")
    }
  }

  return (
    <div className="flex flex-col h-screen bg-gray-900 text-gray-100">
      {/* Header */}
      <header className="border-b border-gray-800 p-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Link href="/" className="mr-2">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <Bot className="h-6 w-6" />
          <h1 className="text-xl font-semibold">AI Chat Assistant</h1>
        </div>
        <Link href="/login">
          <Button variant="outline" size="sm">
            Login
          </Button>
        </Link>
      </header>

      {/* Chat container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center text-gray-500">
            <Bot className="h-12 w-12 mb-4" />
            <h2 className="text-2xl font-semibold mb-2">How can I help you today?</h2>
            <p>Ask me anything and I'll do my best to assist you.</p>
          </div>
        ) : (
          <>
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn(
                  "flex gap-3 max-w-3xl mx-auto",
                  message.role === "user" ? "justify-end" : "justify-start",
                )}
              >
                <div
                  className={cn(
                    "rounded-lg p-4 max-w-[85%]",
                    message.role === "user" ? "bg-blue-600 text-white" : "bg-gray-800 text-gray-100",
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div className="rounded-full bg-gray-700 p-1 h-8 w-8 flex items-center justify-center flex-shrink-0">
                      {message.role === "user" ? <User className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
                    </div>
                    <div className="whitespace-pre-wrap">{message.content}</div>
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </>
        )}

        {/* Show error message if there's an error */}
        {error && (
          <div className="text-red-500 bg-red-500/10 p-4 rounded-md mx-auto max-w-3xl">
            Error: {error.message || "Failed to communicate with AI service. Please try again."}
          </div>
        )}
      </div>

      {/* Input area */}
      <div className="border-t border-gray-800 p-4">
        <form onSubmit={handleSubmit} className="flex flex-col gap-2 max-w-3xl mx-auto relative">
          <Textarea
            value={input}
            onChange={handleTextareaChange}
            placeholder={isLoading ? "AI is thinking..." : "Message AI Assistant..."}
            className={cn("resize-none bg-gray-800 border-gray-700 rounded-lg pr-12", inputHeight)}
            disabled={isLoading}
          />
          <Button
            type="submit"
            size="icon"
            className="absolute bottom-2 right-2 bg-blue-600 hover:bg-blue-700"
            disabled={isLoading || !input.trim()}
          >
            <Send className="h-4 w-4" />
            <span className="sr-only">Send message</span>
          </Button>
        </form>

        {/* Typing indicator */}
        {isLoading && <div className="text-sm text-gray-500 mt-2 text-center">AI is generating a response...</div>}
      </div>
    </div>
  )
}

